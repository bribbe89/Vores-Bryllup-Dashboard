-- Brudebordet -> Supabase (Postgres). Kør i SQL Editor eller via `psql`.
-- Alle id'er er TEXT, så de oprindelige id'er og RSVP-tokens bevares 1:1.
-- Hver tabel har `legacy jsonb` med det originale dokument, så intet går tabt.

create table public.weddings (
  id            text primary key,
  names         text    not null default '',
  wedding_date  date,
  place         text    not null default '',
  site_url      text    not null default '',
  base_url      text    not null default '',
  rsvp_pending  boolean not null default false,
  legacy        jsonb   not null default '{}'
);

-- Hvem må logge ind. Artifactens brugere findes ikke i Supabase Auth, så
-- koblingen user_id <-> person laves efter migreringen (se README).
create table public.wedding_members (
  wedding_id text not null references public.weddings(id) on delete cascade,
  user_id    uuid not null references auth.users(id)     on delete cascade,
  role       text not null default 'admin' check (role in ('admin','contact')),
  sections   text[] not null default '{}',   -- fx {menu,polter,toast,gallery}
  primary key (wedding_id, user_id)
);

-- Kontaktpersoner (fra weddings.contacts / pub/info)
create table public.wedding_contacts (
  id         bigint generated always as identity primary key,
  wedding_id text not null references public.weddings(id) on delete cascade,
  name       text not null default '',
  email      text not null default '',
  sections   text[] not null default '{}',
  user_id    uuid references auth.users(id) on delete set null
);
create index on public.wedding_contacts (wedding_id);

-- ---------- Gæster og RSVP ----------
create table public.guests (
  id            text primary key,                      -- = RSVP-token
  wedding_id    text not null references public.weddings(id) on delete cascade,
  name          text not null default '',
  email         text not null default '',
  phone         text not null default '',
  relation      text not null default '',              -- tidligere "group"
  adults        int  not null default 1,
  children      int  not null default 0,
  status        text not null default 'afventer' check (status in ('afventer','ja','nej')),
  att_adults    int,                                   -- manuelt registreret antal
  att_children  int,
  note          text not null default '',              -- allergi m.m. (manuelt)
  speech_on     boolean not null default false,        -- manuelt registreret indslag
  speech_text   text not null default '',
  linked        boolean not null default false,
  sent_at       timestamptz,
  manual_at     timestamptz,                           -- sidste manuelle rettelse
  created_at    timestamptz,
  legacy        jsonb not null default '{}'
);
create index on public.guests (wedding_id);

create table public.rsvp_config (
  wedding_id       text primary key references public.weddings(id) on delete cascade,
  intro            text not null default '',
  payment          text not null default '',
  speech_enabled   boolean not null default false,
  allergy_enabled  boolean not null default true,
  allergy_label    text not null default '',
  legacy           jsonb not null default '{}'
);

create table public.rsvp_features (                   -- "Funktioner og tilvalg"
  id            text primary key,
  wedding_id    text not null references public.weddings(id) on delete cascade,
  title         text not null default '',
  mode          text not null default 'multi',        -- multi | one
  description   text not null default '',
  add_to_budget boolean not null default false,       -- vises som indtægt under "RSVP"
  sort          int  not null default 0
);
create index on public.rsvp_features (wedding_id);

create table public.rsvp_items (                     -- underpunkter
  id         text primary key,
  feature_id text not null references public.rsvp_features(id) on delete cascade,
  title      text not null default '',
  price      numeric(12,2) not null default 0,
  unit       text not null default '',                -- 'sum' = samlet sum, ellers pr. gæst
  sort       int  not null default 0
);
create index on public.rsvp_items (feature_id);

create table public.rsvp_answers (                   -- gæstens eget svar via linket
  guest_id     text primary key references public.guests(id) on delete cascade,
  wedding_id   text not null references public.weddings(id) on delete cascade,
  status       text not null check (status in ('afventer','ja','nej')),
  adults       int  not null default 0,
  children     int  not null default 0,
  note         text not null default '',
  total        numeric(12,2) not null default 0,       -- egenbetaling
  speech_on    boolean not null default false,
  speech_text  text not null default '',
  answered_at  timestamptz,
  legacy       jsonb not null default '{}'
);
create index on public.rsvp_answers (wedding_id);

create table public.guest_options (                  -- valgte tilvalg, med kilde
  guest_id text not null references public.guests(id)      on delete cascade,
  item_id  text not null references public.rsvp_items(id)  on delete cascade,
  qty      int  not null default 1,
  source   text not null check (source in ('answer','manual')),
  primary key (guest_id, item_id, source)
);

create table public.share_links (                    -- links/{token}
  token      text primary key,
  wedding_id text not null references public.weddings(id) on delete cascade,
  type       text not null check (type in ('rsvp','polter','gallery','toast')),
  guest_id   text references public.guests(id) on delete cascade,
  legacy     jsonb not null default '{}'
);
create index on public.share_links (wedding_id);

-- ---------- Budget ----------
create table public.budget_headings (
  id          text primary key,
  wedding_id  text not null references public.weddings(id) on delete cascade,
  kind        text not null default 'udgift' check (kind in ('udgift','indtaegt')),
  title       text not null default '',
  auto_tasks  boolean not null default false,          -- "Opgaver med budget"
  sort        bigint not null default 0,
  legacy      jsonb not null default '{}'
);
create index on public.budget_headings (wedding_id);

create table public.budget_items (
  id          text primary key,
  wedding_id  text not null references public.weddings(id) on delete cascade,
  heading_id  text references public.budget_headings(id) on delete set null,
  kind        text not null default 'udgift' check (kind in ('udgift','indtaegt')),
  title       text not null default '',
  price       numeric(12,2) not null default 0,        -- oprindeligt
  qty         numeric(12,2) not null default 1,
  mode        text not null default 'fixed',           -- fixed | pr. gæst/voksen/barn
  actual      numeric(12,2),                           -- realiseret (manuel)
  paid        boolean not null default false,
  sort        bigint not null default 0,
  legacy      jsonb not null default '{}'
);
create index on public.budget_items (wedding_id);
create index on public.budget_items (heading_id);

-- ---------- Opgaver og frister ----------
create table public.tasks (
  id             text primary key,
  wedding_id     text not null references public.weddings(id) on delete cascade,
  parent_id      text references public.tasks(id) on delete cascade
                      deferrable initially deferred,   -- underopgaver
  title          text not null default '',
  description    text not null default '',
  due            date,
  status         text not null default 'todo',
  assignee       text not null default '',
  has_budget     boolean not null default false,
  budget_item_id text references public.budget_items(id) on delete set null,
  price          numeric(12,2),
  final_price    numeric(12,2),
  files          jsonb not null default '[]',
  sort           bigint not null default 0,
  created_at     timestamptz,
  legacy         jsonb not null default '{}'
);
create index on public.tasks (wedding_id);
create index on public.tasks (parent_id);

create table public.deadlines (
  id         text primary key,
  wedding_id text not null references public.weddings(id) on delete cascade,
  title      text not null default '',
  due        date,
  note       text not null default '',
  created_at timestamptz,
  legacy     jsonb not null default '{}'
);
create index on public.deadlines (wedding_id);

-- ---------- Bordplan ----------
create table public.rooms (
  wedding_id text primary key references public.weddings(id) on delete cascade,
  width      numeric, height numeric
);

create table public.seating_tables (                 -- borde og øvrige elementer
  id         text primary key,
  wedding_id text not null references public.weddings(id) on delete cascade,
  kind       text not null default 'table',
  no         text not null default '',
  shape      text not null default '',
  width      numeric, height numeric,
  seats      int,
  x          numeric, y numeric,
  created_at timestamptz,
  legacy     jsonb not null default '{}'
);
create index on public.seating_tables (wedding_id);

create table public.table_seats (                    -- personer ved bordene
  id          bigint generated always as identity primary key,
  table_id    text not null references public.seating_tables(id) on delete cascade,
  guest_id    text references public.guests(id) on delete set null,
  name        text not null default '',
  sort        int  not null default 0,
  legacy_id   text,
  legacy      jsonb not null default '{}'
);
create index on public.table_seats (table_id);
create index on public.table_seats (guest_id);

-- ---------- Menu, sider, indslag, galleri ----------
create table public.menu_items (
  id          text primary key,
  wedding_id  text not null references public.weddings(id) on delete cascade,
  title       text not null default '',
  served_on   date,
  served_at   text not null default '',
  description text not null default '',                -- rig tekst (HTML)
  links       jsonb not null default '[]',
  files       jsonb not null default '[]',
  sort        bigint not null default 0,
  created_by  text not null default '',
  legacy      jsonb not null default '{}'
);
create index on public.menu_items (wedding_id);

create table public.pages (                          -- polterabend + toastmaster
  wedding_id text not null references public.weddings(id) on delete cascade,
  kind       text not null check (kind in ('polter','toast')),
  title text not null default '', "when" text not null default '', "where" text not null default '',
  intro text not null default '', program text not null default '', practical text not null default '',
  updated_at timestamptz, updated_by text not null default '',
  legacy jsonb not null default '{}',
  primary key (wedding_id, kind)
);

create table public.speeches (                       -- indslag fra gæster
  id         text primary key,
  wedding_id text not null references public.weddings(id) on delete cascade,
  guest_id   text references public.guests(id) on delete set null,
  name       text not null default '',
  relation   text not null default '',
  body       text not null default '',
  created_at timestamptz,
  sort       bigint not null default 0,
  legacy     jsonb not null default '{}'
);
create index on public.speeches (wedding_id);

create table public.gallery_items (
  id          text primary key,
  wedding_id  text not null references public.weddings(id) on delete cascade,
  asset_id    text,                                    -- id i artifactens asset-lager
  storage_path text,                                   -- udfyldes, når filen er flyttet til Storage
  name        text not null default '',
  mime_type   text not null default '',
  uploaded_by text not null default '',
  created_at  timestamptz,
  legacy      jsonb not null default '{}'
);
create index on public.gallery_items (wedding_id);

-- Gældende status pr. gæst: gæstens eget svar vinder, hvis det er nyere end den
-- seneste manuelle rettelse (samme regel som appen).
create view public.guest_current with (security_invoker = true) as
select g.id, g.wedding_id, g.name, g.relation,
       (a.guest_id is not null and a.answered_at > coalesce(g.manual_at,'epoch'::timestamptz)) as answer_wins,
       case when a.guest_id is not null and a.answered_at > coalesce(g.manual_at,'epoch'::timestamptz) then a.status   else g.status end as status,
       case when a.guest_id is not null and a.answered_at > coalesce(g.manual_at,'epoch'::timestamptz) then a.adults   else coalesce(g.att_adults,g.adults) end as attending_adults,
       case when a.guest_id is not null and a.answered_at > coalesce(g.manual_at,'epoch'::timestamptz) then a.children else coalesce(g.att_children,g.children) end as attending_children,
       case when a.guest_id is not null and a.answered_at > coalesce(g.manual_at,'epoch'::timestamptz) then a.note     else g.note end as note
from public.guests g left join public.rsvp_answers a on a.guest_id = g.id;
