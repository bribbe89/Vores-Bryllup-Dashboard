# Brudebordet → Supabase

Flytter data fra artifactens database til Postgres/Supabase. Pakken flytter **data**; selve appen (artifactet)
læser og skriver stadig i artifactens database, indtil den bygges om til at bruge Supabase.

## Indhold
| Fil | Formål |
|---|---|
| `001_schema.sql` | Tabeller, relationer, indeks og viewet `guest_current` |
| `002_rls.sql` | Row Level Security (admin = alt, kontaktpersoner = deres sektioner) |
| `003_public_rpc.sql` | `rsvp_get`, `rsvp_submit`, `page_get` til gæster uden login |
| `import.mjs` | Læser JSON-sikkerhedskopien og indsætter alt i én transaktion |
| `sample-backup.json` | Lille eksempel til at prøve flowet af |

## Fremgangsmåde
1. I Brudebordet: **Indstillinger → Sikkerhedskopi → Download hele databasen (JSON)**.
2. Kør `001`, `002`, `003` i Supabase SQL Editor (eller `psql "$DATABASE_URL" -f …`) i den rækkefølge.
3. `npm install` og derefter:
   ```
   DATABASE_URL="postgres://postgres:<adgangskode>@db.<projekt>.supabase.co:5432/postgres" \
     node import.mjs brudebordet-….json --dry-run     # test, ruller tilbage
   DATABASE_URL=… node import.mjs brudebordet-….json  # rigtig import
   ```
   Brug evt. `--replace` for at importere forfra (sletter bryllupet først). Scriptet sammenligner rækketal mellem
   fil og database og ruller tilbage, hvis noget ikke stemmer.
4. Opret brugere under Authentication, og tilknyt dem:
   ```sql
   insert into wedding_members(wedding_id,user_id,role) values ('<wedding-id>','<user-uuid>','admin');
   -- kontaktperson: role 'contact', sections '{toast}' / '{menu,polter,gallery}'
   ```

## Datamodel (kort)
- `weddings` 1─n `guests`, `budget_headings`→`budget_items`, `tasks` (selvrelation `parent_id` = underopgaver; `budget_item_id`),
  `deadlines`, `seating_tables`→`table_seats` (→ `guests`), `menu_items`, `speeches` (→ `guests`), `gallery_items`, `pages`, `share_links`.
- RSVP: `rsvp_config` + `rsvp_features`→`rsvp_items` (opsætning), `rsvp_answers` (gæstens eget svar, 1:1 med gæst),
  `guest_options` (valgte tilvalg, `source` = `answer` | `manual`).
- `guest_current` anvender appens regel: gæstens svar vinder, hvis det er nyere end den seneste manuelle rettelse.
- Alle oprindelige id'er og tokens bevares (tekst), så eksisterende RSVP-links fortsat kan slås op.
- Hver tabel har `legacy jsonb` med det originale dokument; felter uden egen kolonne går derfor ikke tabt.

## Skal du være opmærksom på
- **Filer og billeder** (galleri, filer på opgaver og menu) ligger i artifactens asset-lager og følger ikke med i JSON.
  `gallery_items.asset_id` bevares, så de kan hentes og lægges i Supabase Storage; skriv derefter stien i `storage_path`.
- **Brugere:** artifactets brugere findes ikke i Supabase Auth. `wedding_members` og `wedding_contacts.user_id` kobles manuelt.
- **Toastmaster-indhold** er i appen skjult for parret. RLS giver admin adgang til alt; vil du håndhæve skjulet i databasen,
  så fjern admin-adgang til `speeches`/`pages(kind='toast')` og giv kun rollen `contact` med sektionen `toast` adgang.
- Gæsters RSVP-links skal fremover gå via `rsvp_get`/`rsvp_submit` (anon-nøglen), aldrig direkte mod tabellerne.
- Scriptet bruger en direkte Postgres-forbindelse (`pg`), ikke `service_role`-nøglen.

## Hvad der er testet
Schema, RLS-script, funktioner og import er kørt mod en lokal Postgres 16 (med en stub af `auth`-skemaet) med et eksempel,
der indeholder underopgaver, manuelle og egne tilvalg, bordplan, budget og indslag. Resultat: rækketal stemmer, `--replace`
virker, `rsvp_submit` beregner egenbetaling korrekt. Ikke testet: rigtig Supabase-instans og rigtige Auth-brugere
(RLS-reglerne er kun syntakstestet), og `pg`-pakken kunne ikke hentes i testmiljøet, så scriptet blev kørt mod en lille
erstatning, der sender SQL via `psql`.
