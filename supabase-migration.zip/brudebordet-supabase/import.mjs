// Brug:  DATABASE_URL=postgres://... node import.mjs backup.json [--dry-run] [--replace]
//   --dry-run  kører alt i en transaktion og ruller tilbage (til test)
//   --replace  sletter bryllupet først (cascade) og importerer forfra
import fs from 'node:fs';
import pg from 'pg';

const [file, ...flags] = process.argv.slice(2);
if (!file || !process.env.DATABASE_URL) {
  console.error('Brug: DATABASE_URL=... node import.mjs backup.json [--dry-run] [--replace]');
  process.exit(1);
}
const dry = flags.includes('--dry-run'), replace = flags.includes('--replace');
const bk = JSON.parse(fs.readFileSync(file, 'utf8'));
if (bk.format !== 'brudebordet-backup') throw new Error('Ikke en Brudebordet-sikkerhedskopi');
if (bk.notRead?.length) console.warn('ADVARSEL: disse samlinger kunne ikke læses ved eksport:', bk.notRead);

const wid = bk.weddingId, D = bk.data;
const obj = (o) => (o && typeof o === 'object' ? o : {});
const col = (k) => Object.entries(obj(D[k]));            // [[id, doc], ...]
const s = (v) => (v == null ? '' : String(v));
const n = (v, d = 0) => (Number.isFinite(Number(v)) && v !== '' && v != null ? Number(v) : d);
const nn = (v) => (v === '' || v == null || !Number.isFinite(Number(v)) ? null : Number(v));
const ts = (ms) => (Number.isFinite(Number(ms)) && Number(ms) > 0 ? new Date(Number(ms)).toISOString() : null);
const day = (v) => (/^\d{4}-\d{2}-\d{2}$/.test(s(v)) ? v : null);
const arr = (v) => (Array.isArray(v) ? v : []);
const J = (v) => JSON.stringify(v ?? null);
const STATUS = (v) => (['ja', 'nej', 'afventer'].includes(v) ? v : 'afventer');

const client = new pg.Client({ connectionString: process.env.DATABASE_URL });
const counts = {};
async function ins(table, row, conflict) {
  const keys = Object.keys(row), vals = keys.map((k) => (row[k] !== null && typeof row[k] === 'object' && !Array.isArray(row[k]) ? JSON.stringify(row[k]) : row[k]));
  const q = `insert into public.${table} (${keys.map((k) => `"${k}"`).join(',')}) values (${keys.map((_, i) => `$${i + 1}`).join(',')})` +
            (conflict ? ` on conflict (${conflict}) do nothing` : '');
  const r = await client.query(q, vals);
  counts[table] = (counts[table] || 0) + (r.rowCount || 0);
}

await client.connect();
try {
  await client.query('begin');
  if (replace) await client.query('delete from public.weddings where id=$1', [wid]);

  // ---- bryllup + kontaktpersoner
  const w = obj(D['weddings/' + wid]);
  await ins('weddings', { id: wid, names: s(w.names), wedding_date: day(w.date), place: s(w.place), site_url: s(w.siteUrl),
    base_url: s(w.base), rsvp_pending: !!w.rsvpPending, legacy: w });
  const contacts = arr(w.contacts).length ? arr(w.contacts) : arr(obj(D['pub/info/main']).contacts);
  for (const c of contacts)
    await ins('wedding_contacts', { wedding_id: wid, name: s(c.name), email: s(c.email), sections: arr(c.sections) });

  // ---- gæster
  const guestIds = new Set();
  for (const [id, g] of col('priv/guests')) {
    guestIds.add(id);
    await ins('guests', { id, wedding_id: wid, name: s(g.name), email: s(g.email), phone: s(g.phone), relation: s(g.group),
      adults: n(g.adults, 1), children: n(g.children, 0), status: STATUS(g.status),
      att_adults: nn(g.attAdults), att_children: nn(g.attChildren), note: s(g.note),
      speech_on: !!g.speechOn, speech_text: s(g.speechText), linked: !!g.linked,
      sent_at: ts(g.sentAt), manual_at: ts(g.manualAt), created_at: ts(g.createdAt), legacy: g }, 'id');
  }

  // ---- RSVP-opsætning (features -> items)
  const cfg = obj(D['links/cfg']);
  const itemIds = new Set();
  if (D['links/cfg']) {
    await ins('rsvp_config', { wedding_id: wid, intro: s(cfg.intro), payment: s(cfg.payment),
      speech_enabled: !!obj(cfg.speech).on, allergy_enabled: obj(cfg.allergy).on !== false,
      allergy_label: s(obj(cfg.allergy).label), legacy: cfg }, 'wedding_id');
    for (const [fi, f] of arr(cfg.features).entries()) {
      await ins('rsvp_features', { id: f.id, wedding_id: wid, title: s(f.title), mode: s(f.mode) || 'multi',
        description: s(f.desc), add_to_budget: !!f.budget, sort: fi }, 'id');
      for (const [ii, it] of arr(f.items).entries()) {
        itemIds.add(it.id);
        await ins('rsvp_items', { id: it.id, feature_id: f.id, title: s(it.title), price: n(it.price), unit: s(it.unit), sort: ii }, 'id');
      }
    }
  }

  // ---- gæsternes svar + valgte tilvalg (både eget svar og manuelle)
  let skippedOpts = 0;
  const putOpts = async (gid, opts, source) => {
    for (const [item, qty] of Object.entries(obj(opts))) {
      if (!itemIds.has(item)) { skippedOpts++; continue; }       // tilvalg der er slettet fra opsætningen
      await ins('guest_options', { guest_id: gid, item_id: item, qty: Math.max(1, n(qty, 1)), source }, 'guest_id,item_id,source');
    }
  };
  for (const [gid, a] of col('rsvp')) {
    if (!guestIds.has(gid)) { console.warn('RSVP-svar uden gæst sprunget over:', gid); continue; }
    await ins('rsvp_answers', { guest_id: gid, wedding_id: wid, status: STATUS(a.status), adults: n(a.adults), children: n(a.children),
      note: s(a.note), total: n(a.total), speech_on: !!a.speechOn, speech_text: s(a.speechText), answered_at: ts(a.at), legacy: a }, 'guest_id');
    await putOpts(gid, a.opts, 'answer');
  }
  for (const [gid, g] of col('priv/guests')) await putOpts(gid, g.opts, 'manual');

  // ---- links
  for (const [token, l] of col('links')) {
    if (!['rsvp', 'polter', 'gallery', 'toast'].includes(l.type)) continue;
    await ins('share_links', { token, wedding_id: wid, type: l.type, guest_id: l.type === 'rsvp' && guestIds.has(l.gid || token) ? (l.gid || token) : null, legacy: l }, 'token');
  }

  // ---- budget
  const rows = col('priv/budget'), heads = new Set(rows.filter(([, r]) => r.t === 'h').map(([id]) => id)), bItems = new Set();
  for (const [id, r] of rows.filter(([, r]) => r.t === 'h'))
    await ins('budget_headings', { id, wedding_id: wid, kind: r.kind === 'indtaegt' ? 'indtaegt' : 'udgift', title: s(r.title),
      auto_tasks: !!r.autoTasks, sort: n(r.order), legacy: r }, 'id');
  for (const [id, r] of rows.filter(([, r]) => r.t !== 'h')) {
    bItems.add(id);
    await ins('budget_items', { id, wedding_id: wid, heading_id: heads.has(r.parent) ? r.parent : null,
      kind: r.kind === 'indtaegt' ? 'indtaegt' : 'udgift', title: s(r.title), price: n(r.price), qty: n(r.qty, 1),
      mode: s(r.mode) || 'fixed', actual: nn(r.actual), paid: !!r.paid, sort: n(r.order), legacy: r }, 'id');
  }

  // ---- opgaver (underopgaver peger på parent; FK er udskudt til commit)
  const taskIds = new Set(col('priv/tasks').map(([id]) => id));
  for (const [id, t] of col('priv/tasks'))
    await ins('tasks', { id, wedding_id: wid, parent_id: taskIds.has(t.parent) ? t.parent : null, title: s(t.title), description: s(t.desc),
      due: day(t.due), status: s(t.status) || 'todo', assignee: s(t.assignee), has_budget: !!t.hasBudget,
      budget_item_id: bItems.has(t.budgetRow) ? t.budgetRow : null, price: nn(t.price), final_price: nn(t.final),
      files: J(arr(t.files)), sort: n(t.order), created_at: ts(t.createdAt), legacy: t }, 'id');
  for (const [id, d] of col('priv/deadlines'))
    await ins('deadlines', { id, wedding_id: wid, title: s(d.title), due: day(d.date), note: s(d.note), created_at: ts(d.createdAt), legacy: d }, 'id');

  // ---- bordplan
  const room = obj(D['priv/room/main']);
  if (D['priv/room/main']) await ins('rooms', { wedding_id: wid, width: nn(room.w), height: nn(room.h) }, 'wedding_id');
  for (const [id, t] of col('priv/tables')) {
    await ins('seating_tables', { id, wedding_id: wid, kind: s(t.kind) || 'table', no: s(t.no), shape: s(t.shape), width: nn(t.w), height: nn(t.h),
      seats: nn(t.seats), x: nn(t.x), y: nn(t.y), created_at: ts(t.createdAt), legacy: t }, 'id');
    for (const [i, p] of arr(t.ppl).entries())
      await ins('table_seats', { table_id: id, guest_id: guestIds.has(p.gid) ? p.gid : null, name: s(p.name), sort: i, legacy_id: s(p.id), legacy: p });
  }

  // ---- menu, sider, indslag, galleri
  for (const [id, m] of col('pub/menu'))
    await ins('menu_items', { id, wedding_id: wid, title: s(m.title), served_on: day(m.date), served_at: s(m.time), description: s(m.desc),
      links: J(arr(m.links)), files: J(arr(m.files)), sort: n(m.order), created_by: s(m.by), legacy: m }, 'id');
  for (const kind of ['polter', 'toast']) {
    const p = D['pub/' + kind + '/main'];
    if (p) await ins('pages', { wedding_id: wid, kind, title: s(p.title), when: s(p.when), where: s(p.where), intro: s(p.intro),
      program: s(p.program), practical: s(p.practical), updated_at: ts(p.updatedAt), updated_by: s(p.updatedBy), legacy: p }, 'wedding_id,kind');
  }
  for (const [id, sp] of col('pub/speeches'))
    await ins('speeches', { id, wedding_id: wid, guest_id: guestIds.has(sp.gid || id) ? (sp.gid || id) : null, name: s(sp.name), relation: s(sp.group),
      body: s(sp.text), created_at: ts(sp.at), sort: n(sp.order), legacy: sp }, 'id');
  for (const [id, g] of col('pub/gallery'))
    await ins('gallery_items', { id, wedding_id: wid, asset_id: s(g.assetId) || null, name: s(g.name), mime_type: s(g.type),
      uploaded_by: s(g.by), created_at: ts(g.at), legacy: g }, 'id');

  // ---- kontrol: antal rækker i filen mod antal rækker i databasen
  const expect = { guests: col('priv/guests').length, rsvp_answers: col('rsvp').filter(([id]) => guestIds.has(id)).length,
    budget_headings: heads.size, budget_items: bItems.size, tasks: taskIds.size, deadlines: col('priv/deadlines').length,
    seating_tables: col('priv/tables').length, menu_items: col('pub/menu').length, speeches: col('pub/speeches').length,
    gallery_items: col('pub/gallery').length };
  let bad = 0;
  for (const [t, e] of Object.entries(expect)) {
    const { rows: [r] } = await client.query(`select count(*)::int c from public.${t} where ${t === 'rsvp_answers' ? 'wedding_id' : 'wedding_id'}=$1`, [wid]);
    const ok = r.c === e; if (!ok) bad++;
    console.log(`${ok ? 'OK ' : 'FEJL'} ${t.padEnd(16)} fil=${e} db=${r.c}`);
  }
  if (skippedOpts) console.warn(`${skippedOpts} tilvalg refererer til punkter, der ikke findes i RSVP-opsætningen (bevaret i legacy).`);
  console.log('Indsat:', counts);
  if (bad) throw new Error('Rækketal stemmer ikke – ruller tilbage');
  await client.query(dry ? 'rollback' : 'commit');
  console.log(dry ? 'Dry run: rullet tilbage.' : 'Færdig: committet.');
} catch (e) {
  await client.query('rollback').catch(() => {});
  console.error('Import fejlede:', e.message); process.exitCode = 1;
} finally { await client.end(); }
