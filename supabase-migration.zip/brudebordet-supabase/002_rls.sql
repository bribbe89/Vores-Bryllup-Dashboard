-- Row Level Security: svarer til artifactens regler (priv = admin, pub = med link).
-- Anonyme gæster rører aldrig tabellerne direkte; de bruger funktionerne i 003.

create or replace function public.is_wedding_admin(w text) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from wedding_members m where m.wedding_id = w and m.user_id = auth.uid() and m.role = 'admin')
$$;

create or replace function public.has_section(w text, s text) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from wedding_members m where m.wedding_id = w and m.user_id = auth.uid()
                 and (m.role = 'admin' or s = any(m.sections)))
$$;

do $$
declare t text;
begin
  -- Admin har fuld adgang til alt
  foreach t in array array['weddings','wedding_contacts','guests','rsvp_config','rsvp_features','rsvp_answers',
    'share_links','budget_headings','budget_items','tasks','deadlines','rooms','seating_tables',
    'menu_items','pages','speeches','gallery_items','wedding_members']
  loop
    execute format('alter table public.%I enable row level security', t);
  end loop;
end $$;

create policy weddings_admin on public.weddings for all using (public.is_wedding_admin(id)) with check (public.is_wedding_admin(id));
create policy weddings_member_read on public.weddings for select using (exists (select 1 from wedding_members m where m.wedding_id = weddings.id and m.user_id = auth.uid()));
create policy members_admin on public.wedding_members for all using (public.is_wedding_admin(wedding_id)) with check (public.is_wedding_admin(wedding_id));
create policy members_self on public.wedding_members for select using (user_id = auth.uid());

do $$
declare t text;
begin
  foreach t in array array['wedding_contacts','guests','rsvp_config','rsvp_features','rsvp_answers','share_links',
    'budget_headings','budget_items','tasks','deadlines','rooms','seating_tables']
  loop
    execute format('create policy %I on public.%I for all using (public.is_wedding_admin(wedding_id)) with check (public.is_wedding_admin(wedding_id))', t||'_admin', t);
  end loop;
end $$;

-- Tabeller uden wedding_id gå via forælder
alter table public.rsvp_items    enable row level security;
alter table public.guest_options enable row level security;
alter table public.table_seats   enable row level security;
create policy rsvp_items_admin on public.rsvp_items for all
  using (exists (select 1 from rsvp_features f where f.id = feature_id and public.is_wedding_admin(f.wedding_id)))
  with check (exists (select 1 from rsvp_features f where f.id = feature_id and public.is_wedding_admin(f.wedding_id)));
create policy guest_options_admin on public.guest_options for all
  using (exists (select 1 from guests g where g.id = guest_id and public.is_wedding_admin(g.wedding_id)))
  with check (exists (select 1 from guests g where g.id = guest_id and public.is_wedding_admin(g.wedding_id)));
create policy table_seats_admin on public.table_seats for all
  using (exists (select 1 from seating_tables s where s.id = table_id and public.is_wedding_admin(s.wedding_id)))
  with check (exists (select 1 from seating_tables s where s.id = table_id and public.is_wedding_admin(s.wedding_id)));

-- Kontaktpersoner: kun de sektioner, de er koblet på (toastmaster-indhold er skjult for parret i appen;
-- håndhæv det evt. ved at fjerne admin-adgang til speeches/pages 'toast' og kun give den til role 'contact').
create policy menu_contact   on public.menu_items    for all using (public.has_section(wedding_id,'menu'))    with check (public.has_section(wedding_id,'menu'));
create policy gallery_contact on public.gallery_items for all using (public.has_section(wedding_id,'gallery')) with check (public.has_section(wedding_id,'gallery'));
create policy pages_contact  on public.pages         for all using (public.has_section(wedding_id,kind))      with check (public.has_section(wedding_id,kind));
create policy speeches_toast on public.speeches      for all using (public.has_section(wedding_id,'toast'))   with check (public.has_section(wedding_id,'toast'));
