-- Funktioner til gæster uden login. Token = det hemmelige id i linket.
-- Kald fra klienten: supabase.rpc('rsvp_get', { p_token })

create or replace function public.rsvp_get(p_token text) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare r jsonb;
begin
  select jsonb_build_object(
    'guest',  jsonb_build_object('id',g.id,'name',g.name,'relation',g.relation,'adults',g.adults,'children',g.children),
    'wedding',jsonb_build_object('names',w.names,'date',w.wedding_date,'place',w.place),
    'config', jsonb_build_object('intro',c.intro,'payment',c.payment,'speech',c.speech_enabled,
                'allergy',c.allergy_enabled,'allergy_label',c.allergy_label,
                'features',coalesce((select jsonb_agg(jsonb_build_object('id',f.id,'title',f.title,'mode',f.mode,'description',f.description,
                    'items',coalesce((select jsonb_agg(jsonb_build_object('id',i.id,'title',i.title,'price',i.price,'unit',i.unit) order by i.sort)
                                      from rsvp_items i where i.feature_id=f.id),'[]'::jsonb)) order by f.sort)
                    from rsvp_features f where f.wedding_id=w.id),'[]'::jsonb)),
    'answer', (select to_jsonb(a) - 'legacy' from rsvp_answers a where a.guest_id=g.id),
    'options',coalesce((select jsonb_object_agg(o.item_id,o.qty) from guest_options o where o.guest_id=g.id and o.source='answer'),'{}'::jsonb))
  into r
  from share_links l join guests g on g.id=l.guest_id join weddings w on w.id=g.wedding_id
  left join rsvp_config c on c.wedding_id=w.id
  where l.token=p_token and l.type='rsvp';
  return r;
end $$;

create or replace function public.rsvp_submit(
  p_token text, p_status text, p_adults int, p_children int, p_note text,
  p_options jsonb,            -- {"<item_id>": antal}
  p_speech boolean, p_speech_text text) returns void
language plpgsql security definer set search_path = public as $$
declare g guests; total numeric := 0; k text; q int; it rsvp_items;
begin
  select gu.* into g from share_links l join guests gu on gu.id=l.guest_id where l.token=p_token and l.type='rsvp';
  if g.id is null then raise exception 'ukendt link'; end if;
  if p_status not in ('ja','nej') then raise exception 'ugyldigt svar'; end if;

  delete from guest_options where guest_id=g.id and source='answer';
  if p_status='ja' then
    for k, q in select key, greatest(1, least(50, value::int)) from jsonb_each_text(coalesce(p_options,'{}')) loop
      select i.* into it from rsvp_items i join rsvp_features f on f.id=i.feature_id where i.id=k and f.wedding_id=g.wedding_id;
      if it.id is not null then
        insert into guest_options(guest_id,item_id,qty,source) values (g.id,k,q,'answer');
        total := total + it.price * case when it.unit='sum' then 1 else q end;
      end if;
    end loop;
  end if;

  insert into rsvp_answers(guest_id,wedding_id,status,adults,children,note,total,speech_on,speech_text,answered_at)
  values (g.id,g.wedding_id,p_status,
          case when p_status='ja' then greatest(0,coalesce(p_adults,0)) else 0 end,
          case when p_status='ja' then greatest(0,coalesce(p_children,0)) else 0 end,
          case when p_status='ja' then left(coalesce(p_note,''),1000) else '' end, total,
          p_status='ja' and coalesce(p_speech,false), case when p_status='ja' and p_speech then left(coalesce(p_speech_text,''),400) else '' end, now())
  on conflict (guest_id) do update set status=excluded.status, adults=excluded.adults, children=excluded.children,
     note=excluded.note, total=excluded.total, speech_on=excluded.speech_on, speech_text=excluded.speech_text, answered_at=excluded.answered_at;

  if p_status='ja' and coalesce(p_speech,false) then
    insert into speeches(id,wedding_id,guest_id,name,relation,body,created_at,sort)
    values (g.id,g.wedding_id,g.id,g.name,g.relation,left(coalesce(p_speech_text,''),400),now(),(extract(epoch from now())*1000)::bigint)
    on conflict (id) do update set body=excluded.body, created_at=excluded.created_at;
  else
    delete from speeches where id=g.id;
  end if;
end $$;

-- Offentlige sider via token (polterabend / toastmaster)
create or replace function public.page_get(p_token text) returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object('wedding',jsonb_build_object('names',w.names,'date',w.wedding_date,'place',w.place),
                            'page',to_jsonb(p) - 'legacy' - 'wedding_id')
  from share_links l join weddings w on w.id=l.wedding_id left join pages p on p.wedding_id=w.id and p.kind=l.type
  where l.token=p_token and l.type in ('polter','toast')
$$;

revoke all on function public.rsvp_get(text), public.rsvp_submit(text,text,int,int,text,jsonb,boolean,text), public.page_get(text) from public;
grant execute on function public.rsvp_get(text), public.rsvp_submit(text,text,int,int,text,jsonb,boolean,text), public.page_get(text) to anon, authenticated;
